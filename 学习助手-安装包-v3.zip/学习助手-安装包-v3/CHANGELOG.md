# 更新记录

## v3.1 · 2026-11-23

修复 v3 里真题库和考前复习包一启动就崩的问题。

- **修复**：`bin/exams.mjs`、`bin/paper.mjs` 第 7 行用了未定义的 `resolve` 和 `__dirname_`（ESM 里没有 `__dirname`）。没设 `LEARN_HOME` 时直接 `ReferenceError: resolve is not defined`，真题库、考前复习包所有命令全废。现改成和其他脚本一致的标准写法 `path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')`。
- **修复**：`install.sh` 自检补上 `exams.mjs`、`paper.mjs`；这类「缺导入 / 缺定义」的问题以后装的时候就报错，不会再带病装好。
- **修复**：自定义安装目录时，装完提示里的 AGENT.md 路径按实际目录显示。
- **包结构**：zip 解压后就是一层 `学习助手-安装包-v3/` 目录，和安装说明里的命令对得上。

已经装过 v3 的同学不用重装：把 `bin/exams.mjs`、`bin/paper.mjs` 两个文件覆盖到 `/root/学习助手/bin/` 就行；或者在包目录里重跑 `sh install.sh`，它只覆盖脚本、不动已有数据。

## v3 · 2026-11-22

首个公开发布版本。
