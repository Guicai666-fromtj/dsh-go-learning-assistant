#!/bin/sh
# 学习助手 一键安装脚本（dsh-go 手机版 / Android proot）
# 用法：sh install.sh            装到 /root/学习助手
#       sh install.sh 目标目录    装到别处
set -e

TARGET="${1:-/root/学习助手}"
HERE="$(cd "$(dirname "$0")" && pwd)"

echo "== 学习助手 安装 =="
echo "目标目录：$TARGET"

# 1. 检查依赖
echo "-- 检查依赖"
if ! command -v node >/dev/null 2>&1; then
  echo "!! 没找到 node，先在 dsh-go 的「设置 → 本机环境」里装好 Node"
  exit 1
fi
NODE_V="$(node -v)"
echo "   node $NODE_V"
if ! command -v python3 >/dev/null 2>&1; then
  echo "   ! 没找到 python3（只有 qq-read.py 需要，可选）"
fi

# 2. 建目录（不覆盖已有数据）
echo "-- 建目录"
mkdir -p "$TARGET"/bin/handlers "$TARGET"/data "$TARGET"/kb "$TARGET"/mem \
         "$TARGET"/reports "$TARGET"/logs "$TARGET"/tmp

# 3. 拷脚本（脚本可覆盖，数据文件只在不存在时创建）
echo "-- 装脚本"
cp "$HERE"/bin/*.mjs "$TARGET"/bin/ 2>/dev/null || true
cp "$HERE"/bin/*.py  "$TARGET"/bin/ 2>/dev/null || true
cp "$HERE"/bin/handlers/*.mjs "$TARGET"/bin/handlers/ 2>/dev/null || true
mkdir -p "$TARGET"/extras/autox "$TARGET"/docs
cp "$HERE"/extras/autox/timer.js "$TARGET"/extras/autox/ 2>/dev/null || true
cp "$HERE"/docs/*.md "$TARGET"/docs/ 2>/dev/null || true
cp "$HERE"/AGENT.md "$TARGET"/AGENT.md 2>/dev/null || true

chmod +x "$TARGET"/bin/*.mjs 2>/dev/null || true

# 4. 铺模板（只补缺，不动已有）
echo "-- 铺初始数据"
copy_if_absent() {
  [ -e "$2" ] || cp "$1" "$2"
}
copy_if_absent "$HERE/templates/state.json"   "$TARGET/state.json"
copy_if_absent "$HERE/templates/facts.json"   "$TARGET/mem/facts.json"
copy_if_absent "$HERE/templates/threads.json" "$TARGET/mem/threads.json"
copy_if_absent "$HERE/templates/stream.jsonl" "$TARGET/mem/stream.jsonl"
copy_if_absent "$HERE/templates/topics.json"  "$TARGET/kb/topics.json"
copy_if_absent "$HERE/templates/mistakes.jsonl" "$TARGET/kb/mistakes.jsonl"
copy_if_absent "$HERE/templates/weakpoints.md"  "$TARGET/kb/weakpoints.md"
copy_if_absent "$HERE/templates/ops.json"       "$TARGET/ops.json"
for f in scores schedule health study_log; do
  copy_if_absent "$HERE/templates/$f.jsonl" "$TARGET/data/$f.jsonl"
done
copy_if_absent "$HERE/templates/config.example.json" "$TARGET/config.json"

# 5. 自检
echo "-- 自检"
cd "$TARGET"
node bin/state.mjs show >/dev/null && echo "   state.mjs  正常"
node bin/tutor.mjs stats >/dev/null 2>&1 && echo "   tutor.mjs  正常"

echo
echo "装好了。接下来四件事（按顺序做，前两件别跳）："
echo "  1) 编辑 $TARGET/config.json：填称呼、学校、上学/放学时间、入睡/起床时间、身高体重"
echo "  2) 对 dsh-go 说：读 /root/学习助手/AGENT.md，按它带我上手（那份是给助手看的）"
echo "  3) 想让它会讲题：照 docs/01-装DeepTutor与知识库.md 装 DeepTutor 并填 key"
echo "  4) 想精确记学时：照 docs/02-装AutoX计时器.md 导入 extras/autox/timer.js"
echo
echo "包里的东西：bin/（16 个脚本）templates/（空模板）extras/（AutoX 计时脚本）docs/（两篇上手文档）"
echo
echo "常用命令（都在 $TARGET 下跑）："
echo "  node bin/state.mjs show            看档案和欠账"
echo "  node bin/state.mjs metrics         看学习分钟 / 错题 / 到期"
echo "  node bin/tutor.mjs due             今天该复习的错题"
echo "  node bin/supervise.mjs status      看当前学习场次"
echo "  node bin/pet.mjs status            看桌宠小灭"
