# 01 · 装 DeepTutor（解题引擎）+ 本地知识库

这一篇是给「让学习助手会分步讲题」用的。
不想自己敲命令：**把整篇贴给你的 dsh-go，说「照着这篇装好，装完跑 doctor 给我看结果」**。

装完的分工是：

- **dsh-go / 学习助手** = 管理层：账本、错题、复习队列、监督、通道
- **DeepTutor** = 解题引擎：被 HTTP / 命令行调用，负责讲题、多解法、读你的资料

只走调用，**不要让它俩互相读写数据库**，否则两套账对不上。

---

## 一、装核心

```sh
pip install deeptutor
```

装完版本应该是 `deeptutor 1.7.x`。注意：**`deeptutor` 命令通常不在 PATH**，统一用：

```sh
cd /root/deeptutor-test          # 新建一个工作目录，数据都落在这里
python3 -m deeptutor --help
```

初始化：

```sh
python3 -m deeptutor init --cli --non-interactive
python3 -m deeptutor module list
```

初始化会生成 `data/user/settings/`（`main.yaml`、`auth.json`、`model_catalog.json` 等）。

---

## 二、装子模块

```sh
python3 -m deeptutor module install server      # 后端 API（fastapi/uvicorn/pocketbase/redis）
python3 -m deeptutor module install web         # 网页前端（含预构建 Next）
python3 -m deeptutor module install solve       # deep_solve 讲题能力
python3 -m deeptutor module install parsing     # 文档解析
python3 -m deeptutor module install knowledge   # 知识库（llama-index / faiss / bm25s）
```

**坑 1：装模块前必须先停服务**，否则报：
`Environment is in use. Stop DeepTutor before changing modules.`

**坑 2：`knowledge` 模块可能要编译 PyStemmer**，报：
`error: [Errno 2] No such file or directory: 'clang'`
先装：`apt-get update && apt-get install -y clang`

---

## 三、配模型 key（最容易翻车的一步）

改这个文件：

```
/root/deeptutor-test/data/user/settings/model_catalog.json
```

两处都要改。

**1）`connections[]` 加一条（以 DeepSeek 为例）**

```json
{
  "id": "conn-deepseek",
  "provider": "deepseek",
  "name": "deepseek",
  "api_key": "sk-你的key",
  "base_url": "https://api.deepseek.com/v1",
  "api_format": "openai_chat",
  "wire_api": "chat_completions"
}
```

**2）`services.llm.profiles[]` 加一条，并把 `active_profile_id` / `active_model_id` 指过去**

```json
"services": {
  "llm": {
    "active_profile_id": "prof-deepseek",
    "active_model_id": "deepseek-flash",
    "profiles": [
      {
        "id": "prof-deepseek",
        "binding": "deepseek",
        "models": [
          { "id": "deepseek-flash", "model": "deepseek-flash", "name": "deepseek-flash" }
        ]
      }
    ]
  }
}
```

**坑 3：每条 model 必须同时写 `id` 和 `model`。**
源码里是 `_as_str((model or {}).get("model"))` 去取模型名、又按 `id` 去匹配当前选择。
只写 `id` → 报 `No active LLM model is configured.`；只写 `model` → 切不中。

验证：

```sh
python3 -m deeptutor doctor --online
```

要看到：

```
Active model: deepseek-flash (deepseek)
The model returned a response.
```

试跑一题：

```sh
python3 -m deeptutor run deep_solve "解方程 x^2-3x+2=0，按步骤讲" -l zh -f json
```

正常的话 10 秒左右、4 次调用、几厘钱，输出五步解法。

---

## 四、起服务（可选）

只用命令行讲题的话，这一步可以跳过。要网页界面或用 API 才起：

```sh
python3 -m deeptutor start --no-browser
```

- 后端 `http://127.0.0.1:8001`（`/health`、`/docs`）
- 前端 `http://127.0.0.1:3782`
- 内存占用：launcher ~76MB + uvicorn ~105MB + next-server ~98MB

---

## 五、本地嵌入（不出网、不要 key）

```sh
pip install fastembed
python3 /root/学习助手/bin/embed_server.py --port 8010 &
```

服务是 OpenAI 兼容的：`GET /health`、`GET /v1/models`、`POST /v1/embeddings`。
模型 `BAAI/bge-small-zh-v1.5`，512 维，第一次跑会下载模型（约 100MB，走 hf-mirror 更快：
`export HF_ENDPOINT=https://hf-mirror.com`）。

然后在 `model_catalog.json` 里加：

```json
{
  "id": "conn-local-embed",
  "provider": "vllm",
  "name": "local-embed",
  "base_url": "http://127.0.0.1:8010/v1",
  "api_format": "openai_compat",
  "wire_api": "embeddings",
  "api_key": "sk-local"
}
```

并把 `services.embedding` 指过去：

```json
"embedding": {
  "active_profile_id": "prof-bge-zh",
  "active_model_id": "bge-small-zh-v1.5",
  "profiles": [
    {
      "id": "prof-bge-zh",
      "binding": "vllm",
      "models": [
        { "id": "bge-small-zh-v1.5", "model": "bge-small-zh-v1.5", "dim": 512 }
      ]
    }
  ]
}
```

验证：`doctor` 里那条从 `Knowledge module is unavailable` 变成
`No knowledge bases are configured`（这说明模块就绪了，只是还没建库）。

---

## 六、建知识库，把资料喂进去

```sh
cd /root/deeptutor-test
python3 -m deeptutor kb create "数学笔记" -d /path/to/圆锥曲线笔记.md
python3 -m deeptutor kb search "数学笔记" "抛物线焦点弦的二级结论"
```

适合喂的东西：错题本导出、讲义、课本知识点总结、老师发的复习提纲。
PDF 也行（先装 `parsing` 模块）。

带库讲题：

```sh
python3 -m deeptutor run deep_solve "抛物线 y²=4x 的焦点弦，倾角 60°，求弦长。用我笔记里的二级结论。" \
  --kb "数学笔记" -l zh -f json
```

返回里 `sources` 会列出引用了哪份文件、哪一段。

---

## 七、排错清单

| 现象 | 原因 / 解法 |
|---|---|
| `No active LLM model is configured` | `profiles[].models[]` 缺 `model` 字段，或 `active_*` 没指过去 |
| `deeptutor: command not found` | 用 `python3 -m deeptutor` |
| `Environment is in use` | 先停服务再装模块 |
| `No such file or directory: 'clang'` | `apt-get install -y clang` |
| 知识库检索为空 | 嵌入没配好 / 建库时文档没解析成功（看 kb 目录里 raw 有没有文件） |
| 讲题很慢 | 手机 CPU 弱；换小模型或减少 `-l` 上下文 |

---

## 八、回滚

```sh
pip uninstall deeptutor deeptutor-server deeptutor-web deeptutor-solve deeptutor-parsing deeptutor-knowledge
rm -rf /root/deeptutor-test
```

学习助手那边只是「调不调它」，删了不影响记账。
