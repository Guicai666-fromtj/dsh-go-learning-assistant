// 学习计时悬浮窗 v2 (AutoX.js v7)  鬼才专用 / 灭建国 2026-11-12
// 规则：作业/错题=自动（熄屏，或前台在桌面/DSH/AutoX 算专注；切到别的 App 暂停，30 秒内切回不记）
//       听讲/网课/背默=手动开始结束。番茄 25/45/自由。
var DIR = "/sdcard/Download/DSH-Go/autox/";
var CATS = ["作业", "错题", "听讲", "网课", "背默"];
var AUTO = { "作业": 1, "错题": 1 };
var POMO = [25, 45, 0];
var ALLOW_KEY = ["launcher", "home", "autojs", "autox", "dsh", "miui.home", "systemui"];

var cat = "作业", pomoIdx = 0, st = "idle";
var segStart = 0, acc = 0, distractAcc = 0, distractCnt = 0;
var pauseReason = "", pauseAt = 0, pomoAlerted = false, logPath = "", folded = false, reminded = false;
var lastTick = 0;

var DENS = 3;
try { DENS = context.getResources().getDisplayMetrics().density; } catch (e) { }
function dp(n) { return Math.round(n * DENS); }
function pad(n) { return String(n).padStart(2, "0"); }
function hms(sec) {
  sec = Math.max(0, Math.floor(sec));
  var h = Math.floor(sec / 3600), m = Math.floor(sec % 3600 / 60), s = sec % 60;
  return (h ? h + ":" : "") + pad(m) + ":" + pad(s);
}
function bjDay() { return new Date(Date.now() + 8 * 3600e3).toISOString().slice(0, 10); }
function log(o) {
  try {
    if (!logPath) return;
    o.ts = Date.now(); o.bj = new Date(o.ts + 8 * 3600e3).toISOString().slice(0, 19).replace("T", " ");
    files.append(logPath, JSON.stringify(o) + "\n");
  } catch (e) { }
}
function allow(pkg) {
  if (!pkg) return true;
  var p = pkg.toLowerCase();
  for (var i = 0; i < ALLOW_KEY.length; i++) if (p.indexOf(ALLOW_KEY[i]) >= 0) return true;
  return false;
}
try { files.ensureDir(DIR + "x"); logPath = DIR + "timer-" + bjDay() + ".jsonl"; } catch (e) { }

auto.waitFor();

var win = floaty.rawWindow(
  <vertical id="root" bg="#B3000000" padding="6">
    <horizontal id="head" gravity="center_vertical">
      <text id="title" textColor="#FFFFFF" textSize="12sp" text="⏱ 作业 · 25分" layout_weight="1" />
      <text id="fold" textColor="#CCCCCC" textSize="13sp" text="⏶" w="22" gravity="center" />
      <text id="bClose" textColor="#FF8888" textSize="14sp" text="×" w="22" gravity="center" />
    </horizontal>
    <text id="time" textColor="#7CFC00" textSize="22sp" text="00:00" gravity="center" />
    <horizontal id="row" gravity="center_vertical">
      <button id="bMain" text="开始" textSize="10sp" h="30" w="42" />
      <button id="bStop" text="结束" textSize="10sp" h="30" w="36" />
      <button id="bCat" text="分类" textSize="10sp" h="30" w="36" />
      <button id="bPomo" text="25分" textSize="10sp" h="30" w="36" />
    </horizontal>
    <text id="sub" textColor="#AAAAAA" textSize="9sp" text="熄屏/桌面算专注" gravity="center" />
  </vertical>
);
win.setPosition(device.width - dp(196), dp(90));

function sizeWindow() {
  try {
    if (folded) { win.setSize(dp(132), dp(62)); win.title.setVisibility(8); win.row.setVisibility(8); win.sub.setVisibility(8); win.fold.setText("⏷"); }
    else { win.setSize(dp(196), dp(132)); win.title.setVisibility(0); win.row.setVisibility(0); win.sub.setVisibility(0); win.fold.setText("⏶"); }
  } catch (e) { toast("尺寸不支持：" + e); }
}
function refreshTitle() {
  var p = POMO[pomoIdx];
  win.title.setText("⏱ " + cat + " · " + (p ? p + "分" : "自由"));
  win.bPomo.setText(p ? p + "分" : "自由");
}
function setBtn() { win.bMain.setText(st === "run" ? "暂停" : (st === "paused" ? "继续" : "开始")); }
function setStyle(distract) {
  try {
    win.root.setBackgroundColor(colors.parseColor(distract ? "#CC7A0000" : "#B3000000"));
    win.time.setTextColor(colors.parseColor(distract ? "#FFDD55" : "#7CFC00"));
  } catch (e) { }
  if (distract) win.title.setText("⚠ 分心中 · " + cat);
  else refreshTitle();
}

function start() {
  if (st === "run") return;
  st = "run"; segStart = Date.now(); pomoAlerted = false; pauseReason = "";
  log({ ev: "start", cat: cat, pomo: POMO[pomoIdx] }); setBtn(); setStyle(false); reminded = false; toast("开始：" + cat);
}
function pause(reason) {
  if (st !== "run") return;
  acc += (Date.now() - segStart) / 1000; segStart = 0;
  st = "paused"; pauseReason = reason; pauseAt = Date.now();
  log({ ev: "pause", cat: cat, reason: reason, accSec: Math.round(acc) }); setBtn();
  setStyle(reason.indexOf("distract") === 0);
}
function resume() {
  if (st !== "paused") return;
  var gap = (Date.now() - pauseAt) / 1000;
  if (pauseReason.indexOf("distract") === 0 && gap > 30) {
    distractAcc += gap; distractCnt++;
    log({ ev: "distract", cat: cat, pkg: pauseReason.split(":")[1] || "", gapSec: Math.round(gap) });
  }
  st = "run"; segStart = Date.now(); pauseReason = ""; reminded = false; setBtn(); setStyle(false);
  log({ ev: "resume", gapSec: Math.round(gap), accSec: Math.round(acc) });
}
function stop() {
  if (st === "run") acc += (Date.now() - segStart) / 1000;
  segStart = 0;
  log({ ev: "stop", cat: cat, focusSec: Math.round(acc), distractSec: Math.round(distractAcc), distractCnt: distractCnt });
  st = "idle"; acc = 0; distractAcc = 0; distractCnt = 0; pauseReason = ""; pomoAlerted = false;
  win.time.setText("00:00"); setBtn(); toast("本段已记：" + cat);
}

win.bMain.click(function () { if (st === "idle") start(); else if (st === "run") pause("manual"); else resume(); });
win.bStop.click(function () { if (st !== "idle") stop(); else toast("还没开始"); });
win.bCat.click(function () {
  if (st !== "idle") { toast("先结束本段再换分类"); return; }
  cat = CATS[(CATS.indexOf(cat) + 1) % CATS.length]; refreshTitle();
});
win.bPomo.click(function () { pomoIdx = (pomoIdx + 1) % POMO.length; refreshTitle(); });
win.fold.click(function () { folded = !folded; sizeWindow(); });
win.bClose.click(function () {
  toast("计时器已关闭");
  try { if (st !== "idle") stop(); } catch (e) { }
  exit();
});

// 拖动（按住顶部标题条）
var px = device.width - dp(196), py = dp(90), sx = 0, sy = 0, moved = 0;
try {
win.head.setOnTouchListener(new android.view.View.OnTouchListener({
  onTouch: function (v, e) {
    var a = e.getAction();
    if (a === android.view.MotionEvent.ACTION_DOWN) { sx = e.getRawX(); sy = e.getRawY(); moved = 0; }
    else if (a === android.view.MotionEvent.ACTION_MOVE) {
      var dx = e.getRawX() - sx, dy = e.getRawY() - sy;
      if (Math.abs(dx) + Math.abs(dy) > 8) moved = 1;
      if (moved) win.setPosition(px + dx, py + dy);
    } else if (a === android.view.MotionEvent.ACTION_UP) {
      if (moved) { px = px + (e.getRawX() - sx); py = py + (e.getRawY() - sy); }
    }
    return true;
  }
}));
} catch (e) { toast("拖动不可用：" + e); }

setInterval(function () {
  if (st === "run") {
    var el = acc + (Date.now() - segStart) / 1000;
    win.time.setText(hms(el));
    var p = POMO[pomoIdx];
    if (p && !pomoAlerted && el >= p * 60) {
      pomoAlerted = true; toast("番茄到点！休息 5 分钟"); device.vibrate(900);
      log({ ev: "pomo", cat: cat, min: p }); pause("pomo");
    }
    if (AUTO[cat]) {
      var on = device.isScreenOn();
      var pkg = on ? currentPackage() : "";
      if (on && pkg && !allow(pkg)) pause("distract:" + pkg);
    }
    if (Date.now() - lastTick > 300000) { lastTick = Date.now(); log({ ev: "tick", cat: cat, focusSec: Math.round(el) }); }
  } else if (st === "paused" && AUTO[cat]) {
    var on2 = device.isScreenOn();
    var pkg2 = on2 ? currentPackage() : "";
    var gapNow = (Date.now() - pauseAt) / 1000;
    if (pauseReason.indexOf("distract") === 0) {
      win.time.setText("分心 " + hms(gapNow));
      if (gapNow >= 30 && !reminded) {
        reminded = true;
        toast("⏰ 现在是写作业时间哦\n分心的时间不计入学时，回去把作业完成吧");
        device.vibrate(700);
        log({ ev: "remind", cat: cat, gapSec: Math.round(gapNow) });
      }
    }
    if (pauseReason.indexOf("distract") === 0 && (!on2 || !pkg2 || allow(pkg2))) resume();
  } else if (st === "idle") {
    win.time.setText("00:00");
  }
}, 1000);

// 点 × 退出由系统处理；脚本停止时尽量记一笔
try { events.on("exit", function () { if (st === "run") stop(); }); } catch (e) { }

refreshTitle(); setBtn(); sizeWindow();
toast("计时器就绪：点「开始」");
